-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 01, 2018 at 03:08 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `role` varchar(10) DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`, `role`) VALUES
('head@gmail.com', 'head', 'head'),
('teacher1@gmail.com', 'teacher1', 'admin'),
('teacher2@gmail.com', 'teacher1', 'admin'),
('teacher3@gmail.com', 'teacher1', 'admin'),
('mani@gmail.com','mani123','user');
-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('11', '101'),
('12', '107'),
('13', '110'),
('14', '115'),
('15','117'),

('16', '122'),
('17', '127'),
('18', '132'),
('19', '136'),
('20', '140'),

('21', '142'),
('22', '148'),
('23', '149'),
('24', '156'),
('25', '157'),

('26', '162'),
('27', '167'),
('28', '172'),
('29', '175'),
('30', '177'),

('31', '184'),
('32', '185'),
('33', '192'),
('34', '195'),
('35', '197');





-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('11', ' set of programs, documentation & configuration of data', '101'),
('11', 'set of programs', '102'),
('11', ' documentation and configuration of data', '103'),
('11', 'None of the mentioned', '104'),

('12', 'Designing a software', '105'),
('12', 'Testing a software', '106'),
('12', 'Application of engineering principles to the design a software', '107'),
('12', 'None of the above', '108'),

('13', 'Margaret Hamilton', '109'),
('13', 'Watts S. Humphrey', '110'),
('13', 'Alan Turing', '111'),
('13', 'Boris Beizer', '112'),

('14', 'Simplicity', '113'),
('14', 'Accessibility', '114'),
('14', 'Modularity', '115'),
('14', 'All of the above', '116'),

('15', 'Computer-Aided Software Engineering', '117'),
('15', 'Control Aided Science and Engineering', '118'),
('15', 'Cost Aided System Experiments', '119'),
('15', 'None of the mentioned', '120'),

('16', ' It’s an application that alters digital videos', '121'),
('16', 'It’s a software that allows altering digital pictures', '122'),
('16', 'It’s a system that manipulates digital medias', '123'),
('16', 'It’s a machine that allows altering digital images', '124'),

('17', ' Digital Image Processing', '125'),
('17', 'Analog Image Processing', '126'),
('17', ' Both a and b', '127'),
('17', 'None of the above', '128'),

('18', 'Fast image storage and retrieval', '129'),
('18', ' Controlled viewing', '130'),
('18', ' Image reformatting', '131'),
('18', ' All of the above', '132'),

('19', ' Image Enhancement', '133'),
('19', ' Image Classification and Analysis', '134'),
('19', ' Image Transformation', '135'),
('19', 'All of the mentioned', '136'),

('20', ' Computer Graphics', '137'),
('20', 'Pixels', '138'),
('20', 'Camera Mechanism', '139'),
('20', 'All of the mentioned', '140'),

('21', 'Development that involves stack data structures', '141'),
('21', 'Development that involves front-end and back-end programming', '142'),
('21', 'Development that involves only backend programming', '143'),
('21', 'None of the above', '144'),

('22', 'HTML', '145'),
('22', 'CSS', '146'),
('22', 'JavaScript', '147'),
('22', 'SQL', '148'),

('23', 'To provide the client-side interface', '149'),
('23', 'To manage database', '150'),
('23', 'To reduce the server load', '151'),
('23', 'To send http requests', '152'),

('24', 'Python', '153'),
('24', 'C++', '154'),
('24', 'JavaScript', '155'),
('24', 'Both A and C', '156'),

('25', 'A development platform for developing user-interface for software applications', '157'),
('25', 'A database to store and manage the data of an application', '158'),
('25', 'A development platform for writing server-side logic', '159'),
('25', 'None of the above', '160'),

('26', 'client', '161'),
('26', ' server', '162'),
('26', 'tomcat', '163'),
('26', 'applet', '164'),

('27', 'server', '165'),
('27', 'client', '166'),
('27', 'mq', '167'),
('27', 'webapp', '168'),

('28', 'jar', '169'),
('28', 'war', '170'),
('28', ' zip', '171'),
('28', 'both jar and war', '172'),

('29', 'oracle sql developer', '173'),
('29', ' toad', '174'),
('29', ' JDBC template', '175'),
('29', 'mysql', '176'),

('30', 'input tag', '177'),
('30', 'inoutBufferedReader tag', '178'),
('30', ' meta tag', '179'),
('30', 'scanner tag', '180'),

('31', 'Solar energy', '181'),
('31', 'Biomass and biofuel', '182'),
('31', 'Hydropower', '183'),
('31', 'Wind power', '184'),

('32', 'Solar energy', '185'),
('32', 'Biomass and biofuel', '186'),
('32', 'Hydropower', '187'),
('32', 'All of the above', '188'),

('33', 'Solar', '189'),
('33', 'Wave', '190'),
('33', 'Wind', '191'),
('33', 'All of the above', '192'),

('34', 'Nuclear energy', '193'),
('34', 'Fossil fuels', '194'),
('34', 'Both a and b', '195'),
('34', 'None of the above', '196'),

('35', 'Sunlight is free', '197'),
('35', 'Doesn’t produce the greenhouse effect', '198'),
('35', 'Both a and b', '199'),
('35', 'None of the above', '200');

























-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('1', '11', 'Software is defined as', 4, 1),
('1', '12', 'What is Software Engineering?', 4, 2),
('1', '13', 'Who is the father of Software Engineering?', 4, 3),
('1', '14', 'What are the features of Software Code?', 4, 4),
('1', '15', ' CASE stands for', 4, 5),

('2', '16', 'What is Digital Image Processing? ', 4, 1),
('2', '17', 'Which of the following process helps in Image enhancement? ', 4, 2),
('2', '18', 'Among the following, functions that can be performed by digital image processing is?', 4, 3),
('2', '19', ' What are the categories of digital image processing? ', 4,4),
('2', '20', 'What is Digital Image Processing? ', 4, 5),

('3', '21', 'What does the term "Full Stack Development" refer to? ', 4, 1),
('3', '22', ' Which of the following is not a front-end technology? ', 4, 2),
('3', '23', '  The purpose of the Front-end framework in Full stack development', 4, 3),
('3', '24', 'Amongst which of the following programming language is used as a server-side language? ', 4, 4),
('3', '25', 'What is a Front-end framework? ', 4, 5),

('4', '26', ' Servlet are used to program which component in a web application?', 4, 1),
('4', '27', ' Which component can be used for sending messages from one application to another?', 4, 2),
('4', '28', '  How are java web applications packaged?', 4, 3),
('4', '29', ' How can we connect to database in a web application? ', 4, 4),
('4', '30', ' How can we take input text from user in HTML page? ', 4, 5),

('5', '31', ' Which one of the following energy uses windmills for mechanical power?', 4, 1),
('5', '32', ' Which one of the following energy uses solar thermal electricity and solar heating? ', 4, 2),
('5', '33', '________________ are the renewable energy resources ', 4, 3),
('5', '34', ' _______________ are the non-renewable energy resources ', 4, 4),
('5', '35', ' What are the advantages of solar power?', 4, 5);





-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`, `email`) VALUES
('1', 'SOFTWARE ENGINEERING', 2, 1, 5, 10, '', 'SE', '2024-7-26 12:00:00', 'teacher1@gmail.com'),

('2', 'COMPUTER GHAPHICS',    2, 1, 5, 10, '', 'CE', '2024-7-26 12:00:00', 'teacher1@gmail.com'),

('3', 'FULL STACK DEVEPOLMENT',2, 1, 5, 10, '', 'FSD', '2024-7-26 12:00:00', 'teacher1@gmail.com'),

('4', 'ADVANCE JAVA',         2, 1, 5, 10, '', 'JAVA', '2024-7-26 12:00:00', 'teacher1@gmail.com'),

('5', 'RENEWABLE ENERGY POWER PLANT', 2, 1, 5, 10, '', 'REPP', '2024-7-26 12:00:00', 'teacher1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
